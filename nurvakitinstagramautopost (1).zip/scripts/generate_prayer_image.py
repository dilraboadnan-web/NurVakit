#!/usr/bin/env python3
"""Generates the daily NurVakit Instagram post image for a given city.

Fetches prayer times from the Aladhan API (Diyanet calculation method) and
renders them onto a 1080x1350 portrait image saved to assets/instagram/latest.png.
"""
import os
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

import requests
from PIL import Image, ImageDraw, ImageFont

CITY = os.environ.get("PRAYER_CITY", "Istanbul")
COUNTRY = os.environ.get("PRAYER_COUNTRY", "Turkey")
METHOD = "13"  # Diyanet Isleri Baskanligi, Turkey

OUTPUT_PATH = os.path.join(os.path.dirname(__file__), "..", "assets", "instagram", "latest.png")

VAKIT_LABELS = [
    ("Fajr", "İmsak"),
    ("Sunrise", "Güneş"),
    ("Dhuhr", "Öğle"),
    ("Asr", "İkindi"),
    ("Maghrib", "Akşam"),
    ("Isha", "Yatsı"),
]

FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_REGULAR = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

WIDTH, HEIGHT = 1080, 1350
BG_TOP = (9, 42, 58)
BG_BOTTOM = (14, 78, 88)
ACCENT = (247, 197, 87)
TEXT = (255, 255, 255)
SUBTEXT = (200, 220, 220)


def fetch_timings():
    tz = ZoneInfo("Europe/Istanbul")
    today = datetime.now(tz)
    date_str = today.strftime("%d-%m-%Y")
    url = f"https://api.aladhan.com/v1/timingsByCity/{date_str}"
    params = {"city": CITY, "country": COUNTRY, "method": METHOD}
    resp = requests.get(url, params=params, timeout=30)
    resp.raise_for_status()
    data = resp.json()
    if data.get("code") != 200:
        raise RuntimeError(f"Aladhan API error: {data}")
    return today, data["data"]["timings"]


def vertical_gradient(width, height, top, bottom):
    base = Image.new("RGB", (width, height), top)
    draw = ImageDraw.Draw(base)
    for y in range(height):
        ratio = y / height
        r = int(top[0] + (bottom[0] - top[0]) * ratio)
        g = int(top[1] + (bottom[1] - top[1]) * ratio)
        b = int(top[2] + (bottom[2] - top[2]) * ratio)
        draw.line([(0, y), (width, y)], fill=(r, g, b))
    return base


def render_image(today, timings):
    img = vertical_gradient(WIDTH, HEIGHT, BG_TOP, BG_BOTTOM)
    draw = ImageDraw.Draw(img)

    title_font = ImageFont.truetype(FONT_BOLD, 78)
    subtitle_font = ImageFont.truetype(FONT_REGULAR, 40)
    vakit_font = ImageFont.truetype(FONT_BOLD, 46)
    time_font = ImageFont.truetype(FONT_BOLD, 46)

    title = "NurVakit"
    tw = draw.textlength(title, font=title_font)
    draw.text(((WIDTH - tw) / 2, 110), title, font=title_font, fill=ACCENT)

    subtitle = f"{CITY} · {today.strftime('%d.%m.%Y')}"
    sw = draw.textlength(subtitle, font=subtitle_font)
    draw.text(((WIDTH - sw) / 2, 220), subtitle, font=subtitle_font, fill=SUBTEXT)

    start_y = 380
    row_height = 130
    pad_x = 90

    for i, (key, label) in enumerate(VAKIT_LABELS):
        y = start_y + i * row_height
        draw.rounded_rectangle(
            [pad_x, y, WIDTH - pad_x, y + row_height - 20],
            radius=24,
            fill=(255, 255, 255, 30),
            outline=(255, 255, 255),
            width=1,
        )
        draw.text((pad_x + 40, y + 30), label, font=vakit_font, fill=TEXT)
        time_value = timings.get(key, "--:--")
        tw2 = draw.textlength(time_value, font=time_font)
        draw.text((WIDTH - pad_x - 40 - tw2, y + 30), time_value, font=time_font, fill=ACCENT)

    footer = "Diyanet hesaplama yöntemi ile"
    fw = draw.textlength(footer, font=subtitle_font)
    draw.text(((WIDTH - fw) / 2, HEIGHT - 90), footer, font=subtitle_font, fill=SUBTEXT)

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    img.save(OUTPUT_PATH, "PNG")
    return OUTPUT_PATH


def main():
    today, timings = fetch_timings()
    path = render_image(today, timings)
    print(f"Görsel oluşturuldu: {path}")

    caption_path = os.path.join(os.path.dirname(__file__), "..", "assets", "instagram", "latest_caption.txt")
    caption = (
        f"📍 {CITY} - {today.strftime('%d.%m.%Y')}\n\n"
        f"🕌 Bugünün namaz vakitleri:\n"
        f"İmsak: {timings.get('Fajr')} | Güneş: {timings.get('Sunrise')} | "
        f"Öğle: {timings.get('Dhuhr')} | İkindi: {timings.get('Asr')} | "
        f"Akşam: {timings.get('Maghrib')} | Yatsı: {timings.get('Isha')}\n\n"
        f"#namazvakitleri #ezanvakti #{CITY.lower()} #nurvakit #islam #dua"
    )
    with open(caption_path, "w", encoding="utf-8") as f:
        f.write(caption)
    print(f"Açıklama oluşturuldu: {caption_path}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"Hata: {exc}", file=sys.stderr)
        sys.exit(1)
