#!/usr/bin/env python3
"""Publishes assets/instagram/latest.png to Instagram via the Graph API.

Requires environment variables:
  IG_ACCESS_TOKEN   - long-lived access token for the Instagram Business account
  IG_BUSINESS_ID    - Instagram Business Account ID (not the username)
  IMAGE_URL         - public https URL of the image to publish

IMAGE_URL must be reachable by Meta's servers (e.g. a raw.githubusercontent.com
link to the file already committed to the repo).
"""
import os
import sys
import time

import requests

GRAPH_API_VERSION = "v19.0"
GRAPH_API_BASE = f"https://graph.facebook.com/{GRAPH_API_VERSION}"


def require_env(name):
    value = os.environ.get(name)
    if not value:
        print(f"Hata: {name} ortam değişkeni tanımlı değil.", file=sys.stderr)
        sys.exit(1)
    return value


def read_caption():
    caption_path = os.path.join(os.path.dirname(__file__), "..", "assets", "instagram", "latest_caption.txt")
    if os.path.exists(caption_path):
        with open(caption_path, "r", encoding="utf-8") as f:
            return f.read()
    return ""


def create_media_container(business_id, access_token, image_url, caption):
    resp = requests.post(
        f"{GRAPH_API_BASE}/{business_id}/media",
        data={
            "image_url": image_url,
            "caption": caption,
            "access_token": access_token,
        },
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["id"]


def wait_until_ready(container_id, access_token, timeout_seconds=120):
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        resp = requests.get(
            f"{GRAPH_API_BASE}/{container_id}",
            params={"fields": "status_code", "access_token": access_token},
            timeout=30,
        )
        resp.raise_for_status()
        status = resp.json().get("status_code")
        if status == "FINISHED":
            return
        if status == "ERROR":
            raise RuntimeError(f"Medya container işlenemedi: {resp.json()}")
        time.sleep(5)
    raise TimeoutError("Medya container zaman aşımına uğradı.")


def publish_media(business_id, access_token, container_id):
    resp = requests.post(
        f"{GRAPH_API_BASE}/{business_id}/media_publish",
        data={
            "creation_id": container_id,
            "access_token": access_token,
        },
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()


def main():
    access_token = require_env("IG_ACCESS_TOKEN")
    business_id = require_env("IG_BUSINESS_ID")
    image_url = require_env("IMAGE_URL")
    caption = read_caption()

    print(f"Media container oluşturuluyor: {image_url}")
    container_id = create_media_container(business_id, access_token, image_url, caption)
    print(f"Container ID: {container_id}, hazır olması bekleniyor...")
    wait_until_ready(container_id, access_token)

    print("Yayınlanıyor...")
    result = publish_media(business_id, access_token, container_id)
    print(f"Yayınlandı: {result}")


if __name__ == "__main__":
    try:
        main()
    except requests.HTTPError as exc:
        print(f"Graph API hatası: {exc.response.text}", file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        print(f"Hata: {exc}", file=sys.stderr)
        sys.exit(1)
