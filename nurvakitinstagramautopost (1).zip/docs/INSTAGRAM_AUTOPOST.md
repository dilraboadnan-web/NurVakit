# NurVakit Instagram Otomatik Gönderi

Bu otomasyon her gün saat 12:00 (TR saati) İstanbul namaz vakitlerini içeren bir
görsel üretir, repoya commit eder ve Instagram Business hesabına Graph API
üzerinden yayınlar.

## Nasıl çalışıyor

1. `scripts/generate_prayer_image.py` — Aladhan API'den (Diyanet hesaplama
   yöntemi, `method=13`) İstanbul için günün namaz vakitlerini çeker,
   `assets/instagram/latest.png` görselini ve `assets/instagram/latest_caption.txt`
   açıklama metnini üretir.
2. GitHub Actions workflow'u (`.github/workflows/instagram-daily-post.yml`)
   görseli commit'leyip push eder — Instagram Graph API görseli genel erişime
   açık bir URL'den istediği için görsel `raw.githubusercontent.com` üzerinden
   servis edilir.
3. `scripts/post_to_instagram.py` — Instagram Graph API ile bir medya
   container'ı oluşturur, işlenmesini bekler, sonra yayınlar.

## Gerekli kurulum (senin yapman gereken adımlar)

Bu adımları GitHub üzerinden **sen** tamamlamalısın; erişim bilgilerini benimle
paylaşmana gerek yok.

1. Repo → **Settings → Secrets and variables → Actions → New repository secret**
   1. `IG_ACCESS_TOKEN`: Instagram Business hesabına bağlı, Facebook Sayfası
      üzerinden alınmış **long-lived** access token (kısa ömürlü token'lar
      ~1 saatte düşer, otomasyon için long-lived veya sistem kullanıcı token'ı
      kullan).
   2. `IG_BUSINESS_ID`: Instagram Business Account ID (kullanıcı adı değil,
      Graph API `/me/accounts` → sayfa → `instagram_business_account.id`
      üzerinden bulunur).
2. Workflow varsayılan olarak `main` dalında zamanlanmış (`schedule`) tetikleyici
   ile çalışır — GitHub yalnızca **varsayılan daldaki** workflow dosyasını
   zamanlanmış tetikleyiciler için dikkate alır. Bu yüzden bu değişiklikler
   `main`'e alınmadan otomatik günlük çalışma başlamaz.
3. Token süresi dolmadan yenilenmelidir (Meta long-lived token'lar ~60 gün
   geçerlidir); süresi dolarsa yayınlama adımı `190` hata koduyla başarısız olur.

## Manuel test

Workflow'u zamanlamayı beklemeden tetiklemek için: repo → **Actions** →
"NurVakit Instagram Daily Post" → **Run workflow**.

Yerelde görsel üretimini test etmek için (Instagram'a göndermeden):

```bash
pip install -r scripts/requirements.txt
python scripts/generate_prayer_image.py
```

Üretilen dosyalar: `assets/instagram/latest.png`, `assets/instagram/latest_caption.txt`.

## Şehri değiştirmek

Workflow dosyasındaki `PRAYER_CITY` / `PRAYER_COUNTRY` ortam değişkenlerini
güncelle (Aladhan API'nin desteklediği herhangi bir şehir/ülke kullanılabilir).

## Sınırlamalar

- Instagram Graph API günlük yayın sayısına sınır koyar (genelde 25
  gönderi/gün); bu otomasyon günde 1 gönderi attığı için sorun teşkil etmez.
- `raw.githubusercontent.com` CDN'i bazen birkaç saniye gecikmeli güncellenir;
  workflow bu yüzden yayınlamadan önce kısa bir bekleme içerir. Yine de ara
  sıra başarısız olursa workflow'u tekrar tetiklemek yeterlidir.
